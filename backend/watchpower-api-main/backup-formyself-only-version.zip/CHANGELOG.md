# CHANGELOG


## v0.3.0 (2025-01-03)

### Features

- **get_daily_data**: Remove dev addr and dev code default values and improve docstring
  ([`f11d9d7`](https://github.com/davidsmfreire/watchpower-api/commit/f11d9d74455057b4f1a7aa9ff137d0b0530f9867))


## v0.2.0 (2025-01-02)

### Bug Fixes

- Update deprecated example file.
  ([`43142b8`](https://github.com/davidsmfreire/watchpower-api/commit/43142b803ef2d15a0c8aa991680cac9628de6fcc))

### Features

- Add the ability to fetch devices identifiers from the account.
  ([`48899d4`](https://github.com/davidsmfreire/watchpower-api/commit/48899d400666864f8075cd7b42dfc5a51b3cff0a))

- Improve typing and add login validation
  ([`9bf064f`](https://github.com/davidsmfreire/watchpower-api/commit/9bf064fd7ff1f29856c89853fc0df9de0024d3d7))


## v0.1.0 (2024-06-01)
